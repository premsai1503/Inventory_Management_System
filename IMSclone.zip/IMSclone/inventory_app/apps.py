from django.apps import AppConfig


class InventoryAppConfig(AppConfig):
    name = 'inventory_app'
